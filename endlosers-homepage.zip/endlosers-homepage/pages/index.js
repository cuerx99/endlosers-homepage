
import Head from 'next/head'
import { Mail } from 'lucide-react'

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-100 text-gray-900 px-4 py-10">
      <Head>
        <title>End Losers</title>
        <meta name="description" content="End Tech Confusion. End Excuses. End Losers." />
      </Head>
      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-extrabold mb-4">
            End Tech Confusion. <br /> End Excuses. <br /> End Losers.
          </h1>
          <p className="text-xl text-gray-600">
            The fun, no-BS guide for regular humans who want to stop losing to tech.
          </p>
        </header>

        <div className="bg-white shadow-xl p-6 rounded-2xl mb-16">
          <h2 className="text-2xl font-semibold mb-2">
            🎯 Free Download: The 5 Dumbest Tech Mistakes Smart People Make
          </h2>
          <p className="mb-4 text-gray-700">
            Learn how to stop making avoidable tech mistakes (and feel like a genius again).
          </p>
          <form className="flex flex-col sm:flex-row gap-4">
            <input placeholder="Enter your email" type="email" required className="p-2 border rounded" />
            <button type="submit" className="flex items-center justify-center bg-black text-white px-4 py-2 rounded hover:bg-gray-800">
              <Mail className="w-4 h-4 mr-2" /> Get the Free Guide
            </button>
          </form>
        </div>

        <section className="grid md:grid-cols-3 gap-6 mb-16">
          <div className="p-6 bg-white rounded-2xl shadow-md">
            <h3 className="text-lg font-bold mb-2">Tech Tips That Don’t Suck</h3>
            <p className="text-gray-700">No jargon. No condescension. Just fixes that actually help.</p>
          </div>

          <div className="p-6 bg-white rounded-2xl shadow-md">
            <h3 className="text-lg font-bold mb-2">Productivity That Feels Good</h3>
            <p className="text-gray-700">Smart systems, better habits, and fewer digital headaches.</p>
          </div>

          <div className="p-6 bg-white rounded-2xl shadow-md">
            <h3 className="text-lg font-bold mb-2">Humor > Hype</h3>
            <p className="text-gray-700">We're here to entertain as much as we educate. Tech help with a punchline.</p>
          </div>
        </section>

        <footer className="text-center text-gray-600 text-sm mt-20">
          <p>&copy; {new Date().getFullYear()} End Losers. All rights reserved.</p>
          <p className="mt-1">You’re not the problem. Bad systems are. We fix that.</p>
        </footer>
      </div>
    </div>
  )
}
